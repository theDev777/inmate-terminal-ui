import React from 'react';
import InmateTerminal from './InmateTerminal';

function App() {
  return (
    <div>
      <InmateTerminal />
    </div>
  );
}

export default App;