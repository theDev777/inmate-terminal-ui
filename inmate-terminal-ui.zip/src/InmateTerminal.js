import React from 'react';

const InmateTerminal = () => {
  return (
    <div style={{ color: 'limegreen', backgroundColor: 'black', padding: '2rem', height: '100vh' }}>
      <h1>Inmate Terminal UI</h1>
      <p>Booting up the system...</p>
    </div>
  );
};

export default InmateTerminal;